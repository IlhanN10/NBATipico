﻿# NBA Hub – Schulprojekt

Eine kleine Webanwendung mit HTML, CSS und JavaScript. Sie zeigt 30 NBA-Teams. Nutzer können Teams suchen, Favoriten markieren und pro Team eine Notiz anlegen, bearbeiten und löschen.

## Starten

Öffne die Datei `index.html` per Doppelklick in einem aktuellen Browser. Es sind keine Installation, kein Benutzerkonto und kein Internetzugang nötig.

Die Daten werden mit `localStorage` in diesem Browser gespeichert. Beim Löschen der Browserdaten gehen sie verloren. Bei lokalen Dateien kann das Speicherverhalten je nach Browser variieren. Wenn Speichern blockiert ist, zeigt die Anwendung einen Hinweis. Ein anderer Browser oder ein anderer Dateipfad kann einen anderen Speicher verwenden.

Optional für eine einheitliche lokale Adresse, wenn Python installiert ist:

```powershell
python -m http.server 8000 --bind 127.0.0.1
```

Danach `http://127.0.0.1:8000` öffnen. Mit Strg+C den Server beenden.

## Die vier Dateien der Anwendung

| Datei | Aufgabe |
| --- | --- |
| `index.html` | Seitenaufbau, Suchfeld und Favoritenfilter |
| `style.css` | Farben, Abstände und Darstellung auf kleinen Bildschirmen |
| `teams.js` | Array mit den 30 Teams aus dem bisherigen Projekt |
| `script.js` | Karten erstellen, suchen, Favoriten und Notizen speichern |

## So funktioniert der Code

1. Der Browser lädt HTML, CSS und anschließend die beiden JavaScript-Dateien.
2. `loadData()` liest gespeicherte Favoriten und Notizen aus dem Browserspeicher.
3. `createTeamCard()` erstellt für jedes Team eine Karte und registriert Ereignisse für die Knöpfe.
4. `filterTeams()` blendet Karten abhängig von Suche und Favoritenfilter ein oder aus.
5. `saveData()` wandelt die Daten mit `JSON.stringify()` in Text um und speichert sie.

Gespeicherte Daten sehen beispielsweise so aus:

```json
{
  "CHI": { "favorite": true, "note": "Mein Lieblingsteam" }
}
```

Pro Team gibt es eine Notiz mit maximal 500 Zeichen. Zum Bearbeiten ändert man den Text und klickt erneut auf „Notiz speichern“. Ein Klick auf „Notiz löschen“ entfernt den gespeicherten Text. Änderungen im Textfeld allein werden noch nicht gespeichert.

## Abgrenzung

Die Teamdaten sind übernommene Beispieldaten und werden nicht automatisch aktualisiert. Die Schulversion enthält keine Live-Ergebnisse, Spieltipps, Rangliste, Anmeldung oder Serverdatenbank. Die Daten gehören zum verwendeten Browser und werden nicht zwischen Geräten synchronisiert.

Die Dateien der bisherigen React-/Cloudflare-Version bleiben als Referenz im Ordner erhalten. Für das Schulprojekt werden ausschließlich die vier oben genannten Dateien und diese README benötigt. Kopiert diese fünf Dateien gemeinsam in einen neuen Ordner, wenn ihr nur die Schulversion abgeben möchtet. Die bisherige `package.json` gehört zur alten Version; `npm` wird für die Schulversion nicht benötigt. Alte Nutzerdaten werden nicht übernommen.

## Vorschlag für eure Präsentation

- Problem: Lieblingsmannschaften und eigene Notizen übersichtlich sammeln.
- Planung: Suchfeld, Filter und Teamkarten als einfache Skizze zeigen.
- Umsetzung: HTML für Inhalt, CSS für Gestaltung, JavaScript für Verhalten.
- Datenhaltung: Team-Array und Speicherung eigener Einträge als JSON erklären.
- Vorführung: Team suchen, favorisieren, Notiz speichern, neu laden und Notiz bearbeiten.
- Grenzen: lokale Speicherung und statische Daten; mögliche Erweiterung wäre eine Datenbank.

## Manuelle Abnahme

- Ohne Suche werden 30 Teams angezeigt.
- „Chicago“ oder „CHI“ zeigt die Chicago Bulls; eine unbekannte Suche zeigt einen Leerhinweis.
- Favorit markieren und „Nur Favoriten“ aktivieren: nur markierte Teams erscheinen.
- Favorit entfernen: im Favoritenfilter verschwindet die Karte.
- Notiz speichern, Seite neu laden: Favorit und Notiz bleiben erhalten, sofern der Browser Speicherung erlaubt.
- Notiz bearbeiten und speichern, anschließend löschen und neu laden: der Text bleibt gelöscht.
- Einen Text wie `<b>Hallo</b>` speichern: er bleibt normaler Text.
- Seite auf schmalem Fenster und mit Tab/Enter bedienen.
